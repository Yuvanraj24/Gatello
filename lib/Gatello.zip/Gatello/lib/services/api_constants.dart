class ApiConstants {
  static String ip = 'http://3.108.219.188:5000';
  static String signUpip = '$ip/signup';
  static String loginip = '$ip/login';
  
}
