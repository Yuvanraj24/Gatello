class ChatMessage {
  String messageContent;
  String messageType;
  bool selected;
  
  ChatMessage({
    required this.messageContent, 
    required this.messageType,
    required this.selected
    });
  
}
