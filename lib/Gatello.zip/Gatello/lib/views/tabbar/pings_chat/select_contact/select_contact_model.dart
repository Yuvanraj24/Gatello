


class SelectContactModel {
  String dp;
  String name;
  String account;
  bool isSelected;
  SelectContactModel(
      {required this.dp,
        required this.isSelected,
        required this.name,
        required this.account});
}